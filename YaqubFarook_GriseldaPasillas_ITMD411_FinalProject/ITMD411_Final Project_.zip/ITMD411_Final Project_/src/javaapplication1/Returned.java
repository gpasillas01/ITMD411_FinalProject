package javaapplication1;

public class Returned {

}
